@extends('layouts.public')

@section('title', 'Pre-Enrollment Application')

@section('styles')
<link rel="stylesheet" href="{{ asset('css/application-wizard.css') }}">
@stop


@section('content')
<div class="app-wizard-page">

    {{-- ── Top bar ──────────────────────────────────────────────── --}}
    <div class="app-wizard-topbar">
        <a href="{{ route('landing') }}" class="app-wizard-back" aria-label="Back to home">
            <i data-lucide="arrow-left"></i>
        </a>
        <div class="app-wizard-brand">
            <span class="app-wizard-brand-label">DTC EMS</span>
            <span class="app-wizard-brand-title">Pre-Enrollment Application</span>
        </div>
        <div class="app-wizard-progress-label">
            Step <span id="wizCurrentStep">1</span> of <span id="wizTotalSteps">6</span>
        </div>
    </div>

    {{-- ── Step Tracker ─────────────────────────────────────────── --}}
    <div class="app-wizard-tracker" id="wizardTracker" role="list">
        <div class="wiz-step active" data-step="1" role="listitem" tabindex="0">
            <div class="wiz-step-dot"><i data-lucide="graduation-cap"></i></div>
            <span class="wiz-step-label">Program</span>
        </div>
        <div class="wiz-connector"></div>
        <div class="wiz-step" data-step="2" role="listitem" tabindex="0">
            <div class="wiz-step-dot"><i data-lucide="user"></i></div>
            <span class="wiz-step-label">Personal</span>
        </div>
        <div class="wiz-connector"></div>
        <div class="wiz-step" data-step="3" role="listitem" tabindex="0">
            <div class="wiz-step-dot"><i data-lucide="phone"></i></div>
            <span class="wiz-step-label">Contact</span>
        </div>
        <div class="wiz-connector"></div>
        <div class="wiz-step" data-step="4" role="listitem" tabindex="0">
            <div class="wiz-step-dot"><i data-lucide="users"></i></div>
            <span class="wiz-step-label">Family</span>
        </div>
        <div class="wiz-connector"></div>
        <div class="wiz-step" data-step="5" role="listitem" tabindex="0">
            <div class="wiz-step-dot"><i data-lucide="file-up"></i></div>
            <span class="wiz-step-label">Documents</span>
        </div>
        <div class="wiz-connector"></div>
        <div class="wiz-step" data-step="6" role="listitem" tabindex="0">
            <div class="wiz-step-dot"><i data-lucide="clipboard-check"></i></div>
            <span class="wiz-step-label">Review</span>
        </div>
    </div>

    {{-- ── Progress Bar ─────────────────────────────────────────── --}}
    <div class="app-wizard-bar-wrap" aria-hidden="true">
        <div class="app-wizard-bar" id="wizardBar" style="width:20%"></div>
    </div>

    {{-- ── Server-side Validation Errors ───────────────────────── --}}
    @if ($errors->any())
        <div class="wiz-server-errors" id="serverErrors">
            <div class="wiz-server-errors-icon"><i data-lucide="alert-triangle"></i></div>
            <div class="wiz-server-errors-body">
                <p class="wiz-server-errors-title">Your application couldn't be submitted</p>
                <p class="wiz-server-errors-sub">Please fix the following before resubmitting:</p>
                <ul class="wiz-server-errors-list">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        </div>
    @endif

    {{-- ── Screening Notice ─────────────────────────────────────── --}}
    <div class="wiz-notice">
        <i data-lucide="info"></i>
        <div>
            <strong>Preliminary screening only.</strong>
            Uploaded documents are for initial review. You must still present
            original documents to the Registrar's Office before official enrollment.
        </div>
    </div>

    {{-- ══════════════════════════════════════════════════════════ --}}
    <form
        action="{{ route('public.application.store') }}"
        method="POST"
        enctype="multipart/form-data"
        id="applicationForm"
        novalidate
        autocomplete="on"
    >
        @csrf

        {{-- ╔══════════════════════════════════════════════════╗
             ║  STEP 1 — APPLICANT TYPE & PROGRAM              ║
             ╚══════════════════════════════════════════════════╝ --}}
        <div class="wiz-panel active" id="step-1">
            <div class="wiz-panel-header">
                <div class="wiz-panel-icon"><i data-lucide="graduation-cap"></i></div>
                <div>
                    <h2 class="wiz-panel-title">Applicant Type &amp; Program</h2>
                    <p class="wiz-panel-sub">Tell us what type of applicant you are and which program you're applying for.</p>
                </div>
            </div>
            <div class="wiz-panel-body">

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field" id="field-academic_status">
                        <label for="academic_status">Applicant Type <span class="req">*</span></label>
                        <select name="academic_status" id="academic_status"
                            class="wiz-input @error('academic_status') wiz-invalid @enderror"
                            autocomplete="off" required>
                            <option value="">Select applicant type</option>
                            <option value="new_student"    {{ old('academic_status') === 'new_student'    ? 'selected' : '' }}>New Student / First Year</option>
                            <option value="transferee"     {{ old('academic_status') === 'transferee'     ? 'selected' : '' }}>Transferee</option>
                            <option value="shiftee"        {{ old('academic_status') === 'shiftee'        ? 'selected' : '' }}>Shiftee</option>
                            <option value="returnee"       {{ old('academic_status') === 'returnee'       ? 'selected' : '' }}>Returnee / Readmitted</option>
                            <option value="cross_enrollee" {{ old('academic_status') === 'cross_enrollee' ? 'selected' : '' }}>Cross-Enrollee</option>
                        </select>
                        @error('academic_status')
                            <span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="wiz-field" id="field-program_id">
                        <label for="program_id">Intended Program <span class="req">*</span></label>
                        <select name="program_id" id="program_id"
                            class="wiz-input @error('program_id') wiz-invalid @enderror"
                            autocomplete="off" required>
                            <option value="">Select program</option>
                            @foreach ($programs as $program)
                                <option value="{{ $program->id }}" {{ old('program_id') == $program->id ? 'selected' : '' }}>
                                    {{ $program->name }}
                                </option>
                            @endforeach
                        </select>
                        @error('program_id')
                            <span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div id="crossEnrolleeNotice" class="wiz-inline-notice wiz-inline-notice--info d-none">
                    <i data-lucide="info"></i>
                    <div><strong>Cross-Enrollee:</strong> Requirements are subject to confirmation by the Registrar's Office. Please proceed — the Registrar will provide further instructions.</div>
                </div>

            </div>
        </div>


        {{-- ╔══════════════════════════════════════════════════╗
             ║  STEP 2 — PERSONAL INFORMATION                  ║
             ╚══════════════════════════════════════════════════╝ --}}
        <div class="wiz-panel" id="step-2">
            <div class="wiz-panel-header">
                <div class="wiz-panel-icon"><i data-lucide="user"></i></div>
                <div>
                    <h2 class="wiz-panel-title">Personal Information</h2>
                    <p class="wiz-panel-sub">Please provide your personal details accurately.</p>
                </div>
            </div>
            <div class="wiz-panel-body">

                <div class="wiz-row wiz-row--3">
                    <div class="wiz-field" id="field-last_name">
                        <label for="last_name">Last Name <span class="req">*</span></label>
                        <input type="text" name="last_name" id="last_name" placeholder="Dela Cruz"
                            class="wiz-input @error('last_name') wiz-invalid @enderror"
                            value="{{ old('last_name') }}"
                            autocomplete="family-name" required>
                        @error('last_name')<span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>@enderror
                    </div>
                    <div class="wiz-field" id="field-first_name">
                        <label for="first_name">First Name <span class="req">*</span></label>
                        <input type="text" name="first_name" id="first_name" placeholder="Juan"
                            class="wiz-input @error('first_name') wiz-invalid @enderror"
                            value="{{ old('first_name') }}"
                            autocomplete="given-name" required>
                        @error('first_name')<span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>@enderror
                    </div>
                    <div class="wiz-field">
                        <label for="middle_name">Middle Name <span class="opt">(Optional)</span></label>
                        <input type="text" name="middle_name" id="middle_name" placeholder="Santos"
                            class="wiz-input @error('middle_name') wiz-invalid @enderror"
                            value="{{ old('middle_name') }}"
                            autocomplete="additional-name">
                        @error('middle_name')<span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>@enderror
                    </div>
                </div>

                <div class="wiz-row wiz-row--3">
                    <div class="wiz-field" id="field-gender">
                        <label for="gender">Gender <span class="req">*</span></label>
                        <select name="gender" id="gender"
                            class="wiz-input @error('gender') wiz-invalid @enderror"
                            autocomplete="sex" required>
                            <option value="">Select gender</option>
                            <option value="male"   {{ old('gender') === 'male'   ? 'selected' : '' }}>Male</option>
                            <option value="female" {{ old('gender') === 'female' ? 'selected' : '' }}>Female</option>
                        </select>
                        @error('gender')<span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>@enderror
                    </div>
                    <div class="wiz-field" id="field-birthdate">
                        <label for="birthdate">Date of Birth <span class="req">*</span></label>
                        <input type="date" name="birthdate" id="birthdate"
                            class="wiz-input @error('birthdate') wiz-invalid @enderror"
                            value="{{ old('birthdate') }}"
                            autocomplete="bday" required>
                        @error('birthdate')<span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>@enderror
                    </div>
                    <div class="wiz-field">
                        <label for="birth_place">Place of Birth <span class="opt">(Optional)</span></label>
                        <input type="text" name="birth_place" id="birth_place"
                            placeholder="e.g. Danao City, Cebu"
                            class="wiz-input" value="{{ old('birth_place') }}"
                            autocomplete="off">
                    </div>
                </div>

                <div class="wiz-row wiz-row--3">
                    <div class="wiz-field">
                        <label for="religion">Religion <span class="opt">(Optional)</span></label>
                        {{-- Combo: type-ahead via datalist, or pick from dropdown --}}
                        <input type="text" name="religion" id="religion"
                            list="religion-list"
                            placeholder="e.g. Roman Catholic"
                            class="wiz-input" value="{{ old('religion') }}"
                            autocomplete="off">
                        <datalist id="religion-list">
                            <option value="Roman Catholic">
                            <option value="Islam">
                            <option value="Iglesia ni Cristo">
                            <option value="Philippine Independent Church (Aglipayan)">
                            <option value="Seventh-day Adventist">
                            <option value="United Church of Christ in the Philippines">
                            <option value="Christianity (Other)">
                            <option value="Evangelical">
                            <option value="Baptist">
                            <option value="Born-Again Christian">
                            <option value="Jehovah's Witnesses">
                            <option value="The Church of Jesus Christ of Latter-day Saints">
                            <option value="Buddhism">
                            <option value="Hinduism">
                            <option value="No Religion / Atheist / Agnostic">
                            <option value="Prefer not to say">
                        </datalist>
                    </div>
                    <div class="wiz-field">
                        <label for="nationality">Nationality <span class="opt">(Optional)</span></label>
                        <input type="text" name="nationality" id="nationality" placeholder="Filipino"
                            class="wiz-input" value="{{ old('nationality', 'Filipino') }}"
                            autocomplete="off">
                    </div>
                    <div class="wiz-field">
                        <label for="lrn">LRN <span class="opt">(Optional)</span></label>
                        <input type="text" name="lrn" id="lrn" placeholder="136041123456"
                            class="wiz-input" value="{{ old('lrn') }}" maxlength="12"
                            autocomplete="off">
                        <span class="wiz-hint">Learner Reference Number — for DepEd graduates.</span>
                    </div>
                </div>

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="marital_status">Marital Status <span class="opt">(Optional)</span></label>
                        <select name="marital_status" id="marital_status" class="wiz-input" autocomplete="off">
                            <option value="">Select status</option>
                            <option value="single"   {{ old('marital_status') === 'single'   ? 'selected' : '' }}>Single</option>
                            <option value="married"  {{ old('marital_status') === 'married'  ? 'selected' : '' }}>Married</option>
                            <option value="divorced" {{ old('marital_status') === 'divorced' ? 'selected' : '' }}>Divorced</option>
                            <option value="widowed"  {{ old('marital_status') === 'widowed'  ? 'selected' : '' }}>Widowed</option>
                        </select>
                    </div>
                    <div class="wiz-field" id="spouseField">
                        <label for="spouse_name">Spouse Name <span class="opt">(Optional)</span></label>
                        <input type="text" name="spouse_name" id="spouse_name"
                            placeholder="Spouse's full name"
                            class="wiz-input" value="{{ old('spouse_name') }}"
                            autocomplete="off">
                    </div>
                </div>

            </div>
        </div>


        {{-- ╔══════════════════════════════════════════════════╗
             ║  STEP 3 — CONTACT INFORMATION                   ║
             ╚══════════════════════════════════════════════════╝ --}}
        <div class="wiz-panel" id="step-3">
            <div class="wiz-panel-header">
                <div class="wiz-panel-icon"><i data-lucide="phone"></i></div>
                <div>
                    <h2 class="wiz-panel-title">Contact Information</h2>
                    <p class="wiz-panel-sub">Where can we reach you regarding your application?</p>
                </div>
            </div>
            <div class="wiz-panel-body">

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field" id="field-email">
                        <label for="email">Email Address <span class="req">*</span></label>
                        <input type="email" name="email" id="email" placeholder="juandelacruz@email.com"
                            class="wiz-input @error('email') wiz-invalid @enderror"
                            value="{{ old('email') }}"
                            autocomplete="email" required>
                        @error('email')<span class="wiz-err-msg"><i data-lucide="alert-circle"></i>{{ $message }}</span>@enderror
                    </div>
                    <div class="wiz-field">
                        <label for="phone">Contact Number <span class="opt">(Optional)</span></label>
                        <input type="text" name="phone" id="phone" placeholder="09XXXXXXXXX"
                            class="wiz-input" value="{{ old('phone') }}"
                            autocomplete="tel-national">
                    </div>
                </div>

                {{-- ── Street / House address ─────────────────── --}}
                <div class="wiz-field">
                    <label for="current_address">House No., Street <span class="opt">(Optional)</span></label>
                    <input type="text" name="current_address" id="current_address"
                        placeholder="e.g. 12 Rizal Street, Poblacion"
                        class="wiz-input" value="{{ old('current_address') }}"
                        autocomplete="street-address">
                </div>

                {{-- ── Cascading PH location ──────────────────── --}}
                {{--
                    VISIBLE: 4 <select> dropdowns (Region → Province → City → Barangay)
                    HIDDEN:  4 text inputs submitted to the server with human-readable names
                    The JS cascade in application-wizard.js drives everything.
                --}}

                {{-- Hidden text inputs that the server actually receives --}}
                <input type="hidden" name="region"   id="region_text"   value="{{ old('region') }}">
                <input type="hidden" name="province" id="province_text" value="{{ old('province') }}">
                <input type="hidden" name="city"     id="city_text"     value="{{ old('city') }}">
                <input type="hidden" name="barangay" id="barangay_text" value="{{ old('barangay') }}">

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="addr_region">Region <span class="opt">(Optional)</span></label>
                        <div class="loc-select-wrap loc-loading">
                            <select id="addr_region" name="_addr_region" class="loc-select wiz-input"
                                autocomplete="off" disabled>
                                <option value="">Loading regions…</option>
                            </select>
                        </div>
                    </div>
                    <div class="wiz-field">
                        <label for="addr_province">Province <span class="opt">(Optional)</span></label>
                        <div class="loc-select-wrap">
                            <select id="addr_province" name="_addr_province" class="loc-select wiz-input"
                                autocomplete="off" disabled>
                                <option value="">Select province…</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="addr_city">City / Municipality <span class="opt">(Optional)</span></label>
                        <div class="loc-select-wrap">
                            <select id="addr_city" name="_addr_city" class="loc-select wiz-input"
                                autocomplete="address-level2" disabled>
                                <option value="">Select city / municipality…</option>
                            </select>
                        </div>
                    </div>
                    <div class="wiz-field">
                        <label for="addr_barangay">Barangay <span class="opt">(Optional)</span></label>
                        <div class="loc-select-wrap">
                            <select id="addr_barangay" name="_addr_barangay" class="loc-select wiz-input"
                                autocomplete="off" disabled>
                                <option value="">Select barangay…</option>
                            </select>
                        </div>
                    </div>
                </div>

                {{-- Postal code (auto-filled when city is picked, also editable) --}}
                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="postal_code">Postal Code <span class="opt">(Optional)</span></label>
                        <input type="text" name="postal_code" id="postal_code" placeholder="e.g. 6004"
                            class="wiz-input" value="{{ old('postal_code') }}"
                            autocomplete="postal-code" inputmode="numeric" maxlength="4">
                        <span class="wiz-hint">Auto-filled when you select a city or barangay — you can edit it.</span>
                    </div>
                    <div class="wiz-field" style="max-width:220px">
                        <label for="country">Country</label>
                        <input type="text" name="country" id="country" placeholder="Philippines"
                            class="wiz-input" value="{{ old('country', 'Philippines') }}"
                            autocomplete="country-name">
                    </div>
                </div>

                {{-- Address summary chip — shown by JS once all 4 selects are filled --}}
                <div class="loc-summary" id="locSummary">
                    <i data-lucide="map-pin"></i>
                    <span id="locSummaryText"></span>
                </div>

            </div>
        </div>


        {{-- ╔══════════════════════════════════════════════════╗
             ║  STEP 4 — FAMILY & OTHER INFORMATION            ║
             ╚══════════════════════════════════════════════════╝ --}}
        <div class="wiz-panel" id="step-4">
            <div class="wiz-panel-header">
                <div class="wiz-panel-icon"><i data-lucide="users"></i></div>
                <div>
                    <h2 class="wiz-panel-title">Family &amp; Other Information</h2>
                    <p class="wiz-panel-sub">Optional — kept for the Registrar's records.</p>
                </div>
            </div>
            <div class="wiz-panel-body">

                <p class="wiz-group-label"><i data-lucide="heart"></i> Parent / Guardian</p>

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="father_name">Father's Name</label>
                        <input type="text" name="father_name" id="father_name"
                            placeholder="Father's full name" class="wiz-input"
                            value="{{ old('father_name') }}" autocomplete="off">
                    </div>
                    <div class="wiz-field">
                        <label for="father_occupation">Father's Occupation</label>
                        <input type="text" name="father_occupation" id="father_occupation"
                            placeholder="e.g. Driver, Farmer, OFW" class="wiz-input"
                            value="{{ old('father_occupation') }}" autocomplete="off">
                    </div>
                </div>

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="mother_name">Mother's Name</label>
                        <input type="text" name="mother_name" id="mother_name"
                            placeholder="Mother's full name" class="wiz-input"
                            value="{{ old('mother_name') }}" autocomplete="off">
                    </div>
                    <div class="wiz-field">
                        <label for="mother_occupation">Mother's Occupation</label>
                        <input type="text" name="mother_occupation" id="mother_occupation"
                            placeholder="e.g. Housewife, Teacher, OFW" class="wiz-input"
                            value="{{ old('mother_occupation') }}" autocomplete="off">
                    </div>
                </div>

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="parent_address">Parent's Address</label>
                        <input type="text" name="parent_address" id="parent_address"
                            placeholder="Same as current address, if applicable" class="wiz-input"
                            value="{{ old('parent_address') }}" autocomplete="off">
                    </div>
                    <div class="wiz-field">
                        <label for="parent_contact">Parent's Contact</label>
                        <input type="text" name="parent_contact" id="parent_contact"
                            placeholder="09XXXXXXXXX" class="wiz-input"
                            value="{{ old('parent_contact') }}" autocomplete="off">
                    </div>
                </div>

                <div class="wiz-divider"></div>
                <p class="wiz-group-label"><i data-lucide="clipboard-list"></i> Other Details</p>

                <div class="wiz-row wiz-row--2">
                    <div class="wiz-field">
                        <label for="occupation">Occupation <span class="opt">(Optional)</span></label>
                        <input type="text" name="occupation" id="occupation"
                            placeholder="e.g. Student, Employed, Self-employed" class="wiz-input"
                            value="{{ old('occupation') }}" autocomplete="organization-title">
                    </div>
                    <div class="wiz-field">
                        <label for="disability">Disability <span class="opt">(Optional)</span></label>
                        <input type="text" name="disability" id="disability"
                            placeholder="If applicable" class="wiz-input"
                            value="{{ old('disability') }}" autocomplete="off">
                    </div>
                </div>

                <div class="wiz-field d-none" id="pwdIdField" style="max-width:360px">
                    <label for="pwd_id">PWD ID Number <span class="opt">(Optional)</span></label>
                    <input type="text" name="pwd_id" id="pwd_id"
                        placeholder="PWD ID number, if applicable" class="wiz-input"
                        value="{{ old('pwd_id') }}" autocomplete="off">
                </div>

            </div>
        </div>


        {{-- ╔══════════════════════════════════════════════════╗
             ║  STEP 5 — DOCUMENTS + REVIEW + SUBMIT           ║
             ╚══════════════════════════════════════════════════╝ --}}
        <div class="wiz-panel" id="step-5">
            <div class="wiz-panel-header">
                <div class="wiz-panel-icon"><i data-lucide="file-up"></i></div>
                <div>
                    <h2 class="wiz-panel-title">Supporting Documents &amp; Submit</h2>
                    <p class="wiz-panel-sub">Optional digital uploads for preliminary screening. Review everything before submitting.</p>
                </div>
            </div>
            <div class="wiz-panel-body">

                {{-- ── Tab Navigation ─────────────────────────────── --}}
                <div class="doc-tabs" role="tablist">
                    <button type="button" class="doc-tab-btn active"
                        data-tab="uploads" role="tab" aria-selected="true">
                        <i data-lucide="upload-cloud"></i> Upload Documents
                    </button>
                    <button type="button" class="doc-tab-btn"
                        data-tab="checklist" role="tab" aria-selected="false">
                        <i data-lucide="clipboard-check"></i> Requirements Checklist
                    </button>
                </div>

                {{-- ── Tab Panel: Upload Documents ─────────────────── --}}
                <div class="doc-tab-panel active" data-tab-panel="uploads" role="tabpanel">

                    <div id="noDocumentNotice" class="wiz-inline-notice wiz-inline-notice--neutral">
                        <i data-lucide="info"></i>
                        <span>Select your applicant type in Step 1 to see the applicable document uploads.</span>
                    </div>

                    {{-- New Student --}}
                    <div class="document-section d-none" data-type="new_student">
                        <div class="wiz-inline-notice wiz-inline-notice--info" style="margin-bottom:16px">
                            <i data-lucide="info"></i>
                            <div><strong>New Student / First Year</strong> — documents below are optional for preliminary screening.</div>
                        </div>
                        @include('public.application.partials.document-input', ['name'=>'form_138','label'=>'Form 138 or Equivalent','description'=>'Issued by your originating school.'])
                        @include('public.application.partials.document-input', ['name'=>'good_moral_certificate','label'=>'Certificate of Good Moral Character','description'=>'Issued by your originating school.'])
                        @include('public.application.partials.document-input', ['name'=>'birth_certificate','label'=>'PSA Birth Certificate','description'=>'Digital copy for preliminary screening.'])
                    </div>

                    {{-- Transferee --}}
                    <div class="document-section d-none" data-type="transferee">
                        <div class="wiz-inline-notice wiz-inline-notice--info" style="margin-bottom:16px">
                            <i data-lucide="info"></i>
                            <div><strong>Transferee</strong> — documents below are optional for preliminary screening.</div>
                        </div>
                        @include('public.application.partials.document-input', ['name'=>'transfer_credentials','label'=>'Certificate of Transfer Credentials','description'=>'Issued by your originating school.'])
                        @include('public.application.partials.document-input', ['name'=>'transcript_of_records','label'=>'Transcript of Records','description'=>'For preliminary evaluation.'])
                        @include('public.application.partials.document-input', ['name'=>'good_moral_certificate','label'=>'Certificate of Good Moral Character','description'=>'Issued by your originating school.'])
                        @include('public.application.partials.document-input', ['name'=>'birth_certificate','label'=>'PSA Birth Certificate','description'=>'Digital copy for preliminary screening.'])
                    </div>

                    {{-- Shiftee --}}
                    <div class="document-section d-none" data-type="shiftee">
                        <div class="wiz-inline-notice wiz-inline-notice--neutral">
                            <i data-lucide="info"></i>
                            <span>No document upload required for Shiftees at this stage. The Registrar's Office will provide further instructions.</span>
                        </div>
                    </div>

                    {{-- Returnee --}}
                    <div class="document-section d-none" data-type="returnee">
                        <div class="wiz-inline-notice wiz-inline-notice--neutral">
                            <i data-lucide="info"></i>
                            <span>No additional document upload required for Returnees. The Registrar's Office will provide further instructions.</span>
                        </div>
                    </div>

                    {{-- Cross-Enrollee --}}
                    <div class="document-section d-none" data-type="cross_enrollee">
                        <div class="wiz-inline-notice wiz-inline-notice--info">
                            <i data-lucide="info"></i>
                            <div><strong>Cross-Enrollee:</strong> Requirements are subject to confirmation by the Registrar's Office.</div>
                        </div>
                    </div>

                    {{-- Marriage Certificate --}}
                    <div id="marriageDocument" class="d-none" style="margin-top:20px">
                        <div class="wiz-divider"></div>
                        <p class="wiz-group-label"><i data-lucide="bell-ring"></i> Marriage Certificate</p>
                        <p style="font-size:13px;color:#64748b;margin:-8px 0 14px">Applicable only to married applicants. Upload is optional.</p>
                        @include('public.application.partials.document-input', ['name'=>'marriage_certificate','label'=>'Marriage Certificate (PSA)','description'=>'Upload if applicable.'])
                    </div>

                </div>{{-- end uploads tab panel --}}

                {{-- ── Tab Panel: Requirements Checklist ──────────── --}}
                <div class="doc-tab-panel" data-tab-panel="checklist" role="tabpanel">

                    <div id="physicalRequirementsCard" class="wiz-reqs">
                        <div class="wiz-reqs-header">
                            <i data-lucide="folder-open"></i>
                            Physical Requirements to Bring
                        </div>
                        <p class="wiz-reqs-sub">
                            These must be presented at the Registrar's Office regardless of digital uploads.
                            Tick each item off as you prepare it — this checklist is for your reference only.
                        </p>
                        <ul id="physicalRequirementsList" class="wiz-reqs-checklist">
                            <li>
                                <span class="wiz-reqs-empty">
                                    Select your applicant type in Step 1 to see the requirements list.
                                </span>
                            </li>
                        </ul>
                    </div>

                </div>{{-- end checklist tab panel --}}


            </div>
        </div>

        {{-- ╔══════════════════════════════════════════════════╗
             ║  STEP 6 — REVIEW & SUBMIT                        ║
             ╚══════════════════════════════════════════════════╝ --}}
        <div class="wiz-panel" id="step-6">
            <div class="wiz-panel-header">
                <div class="wiz-panel-icon"><i data-lucide="clipboard-check"></i></div>
                <div>
                    <h2 class="wiz-panel-title">Review Your Application</h2>
                    <p class="wiz-panel-sub">Please check all your details carefully before submitting.</p>
                </div>
            </div>
            <div class="wiz-panel-body">

                {{-- ── Review Summary (populated by JS buildReview()) ── --}}
                <div id="reviewSummary" class="rev-summary">
                    <div class="rev-loading">
                        <i data-lucide="loader"></i> Loading your summary…
                    </div>
                </div>

                <div class="wiz-divider"></div>

                {{-- ── Terms & Privacy — Google-style scrollable consent box ── --}}
                <div class="consent-wrap">

                    {{-- Header --}}
                    <div class="consent-head">
                        <i data-lucide="shield-check"></i>
                        <div>
                            <h3 class="consent-title">Before you submit</h3>
                            <p class="consent-sub">Read the following terms carefully. Scroll to the bottom to continue.</p>
                        </div>
                    </div>

                    {{-- Scrollable body --}}
                    <div class="consent-scroll" id="consentScroll">

                        <h4 class="consent-section-title">
                            <i data-lucide="file-text"></i> Enrollment Terms & Conditions
                        </h4>
                        <p>
                            This pre-enrollment form is a <strong>preliminary application only</strong> and does
                            not guarantee admission or constitute official enrollment at Danao Technological College (DTC).
                            Submission of this form initiates the screening process, which is subject to review and
                            approval by the Registrar's Office.
                        </p>
                        <p>
                            You are required to appear in person at the Registrar's Office and present all original
                            documents listed in the Requirements Checklist. Failure to present complete and authentic
                            documents may result in the cancellation of your application without prior notice.
                        </p>
                        <p>
                            DTC reserves the right to reject any application found to contain false, misleading, or
                            incomplete information. Any misrepresentation of credentials or personal details is grounds
                            for immediate disqualification and may be subject to applicable legal consequences.
                        </p>
                        <p>
                            Acceptance into a program is contingent on the availability of slots, passing of any
                            required entrance evaluations, and compliance with all admission requirements as determined
                            by the college.
                        </p>

                        <div class="consent-divider"></div>

                        <h4 class="consent-section-title">
                            <i data-lucide="lock"></i> Data Privacy Notice
                            <span class="consent-law-badge">RA 10173</span>
                        </h4>
                        <p>
                            In compliance with <strong>Republic Act 10173 — Data Privacy Act of 2012</strong>,
                            Danao Technological College informs you that the personal information you provide in this
                            form will be collected, stored, and processed for the following lawful purposes:
                        </p>
                        <ul>
                            <li>Processing and evaluating your enrollment application</li>
                            <li>Verifying submitted documents and academic credentials</li>
                            <li>Communicating with you regarding your application status and enrollment requirements</li>
                            <li>Maintaining official student records as required by CHED and applicable government regulations</li>
                            <li>Statistical and research purposes in anonymized or aggregated form</li>
                        </ul>
                        <p>
                            Your personal data will be kept strictly confidential and will only be accessible to
                            authorized DTC personnel directly involved in the enrollment process. It will not be
                            sold, rented, or disclosed to any third party without your written consent, except
                            when required or permitted by law.
                        </p>
                        <p>
                            Your data will be retained only for as long as necessary to fulfill the purposes stated
                            above, or as required by applicable regulations.
                        </p>

                        <div class="consent-highlight">
                            <i data-lucide="user-check"></i>
                            <div>
                                <strong>Your Rights under RA 10173</strong>
                                <p>You have the right to be informed, to access your data, to correct inaccuracies,
                                to object to processing, to erasure or blocking, and to lodge a complaint with the
                                National Privacy Commission (NPC) at <em>complaints@privacy.gov.ph</em>.</p>
                                <p>For data privacy concerns, contact the DTC Data Protection Officer at the
                                Registrar's Office or via the official DTC institutional email.</p>
                            </div>
                        </div>

                        {{-- Scroll sentinel — JS watches this to unlock checkboxes --}}
                        <div id="consentScrollEnd" style="height:1px"></div>
                    </div>

                    {{-- Scroll-to-bottom nudge --}}
                    <div class="consent-scroll-nudge" id="consentNudge">
                        <i data-lucide="chevrons-down"></i>
                        <span>Scroll down to read all terms</span>
                    </div>

                    {{-- Two named checkboxes, locked until scrolled --}}
                    <div class="consent-checks" id="consentChecks">

                        <label class="consent-check-label" for="ack_enrollment" id="ackEnrollmentLabel">
                            <span class="consent-check-box-wrap">
                                <input type="checkbox" id="ack_enrollment" name="ack_enrollment"
                                    class="consent-chk" disabled required>
                                <span class="consent-check-box"></span>
                            </span>
                            <span class="consent-check-text">
                                I have read and understood the <strong>Enrollment Terms & Conditions</strong>.
                                I acknowledge that this submission does not guarantee enrollment and that I must
                                present original documents to the Registrar's Office.
                            </span>
                        </label>

                        <label class="consent-check-label" for="ack_privacy" id="ackPrivacyLabel">
                            <span class="consent-check-box-wrap">
                                <input type="checkbox" id="ack_privacy" name="ack_privacy"
                                    class="consent-chk" disabled required>
                                <span class="consent-check-box"></span>
                            </span>
                            <span class="consent-check-text">
                                I have read the <strong>Data Privacy Notice</strong> and I freely give my consent
                                to Danao Technological College to collect and process my personal information
                                in accordance with <strong>RA 10173</strong>.
                            </span>
                        </label>

                        {{-- Hidden field for server validation (set by JS when both are checked) --}}
                        <input type="hidden" name="acknowledgement" id="acknowledgement" value="">

                        <div class="wiz-err-msg d-none" id="ackError" style="margin-top:4px">
                            <i data-lucide="alert-circle"></i> You must agree to both statements above before submitting.
                        </div>

                    </div>
                </div>

            </div>
        </div>

        {{-- ── Wizard Navigation ────────────────────────────────────── --}}
        <div class="wiz-nav">
            <button type="button" class="wiz-btn wiz-btn--ghost" id="wizPrev" style="visibility:hidden">
                <i data-lucide="arrow-left"></i> Previous
            </button>
            <button type="button" class="wiz-btn wiz-btn--primary" id="wizNext">
                Next <i data-lucide="arrow-right"></i>
            </button>
            <button type="submit" class="wiz-btn wiz-btn--submit d-none" id="wizSubmit">
                <i data-lucide="send"></i> Submit Application
            </button>
        </div>

    </form>
</div>
@stop


@section('scripts')
<script src="{{ asset('js/application-wizard.js') }}" defer></script>
<script>
    /* Tell the wizard which step to open first.
       Runs after application-wizard.js because it is defer-loaded
       but this inline script runs after DOMContentLoaded as well. */
    document.addEventListener('DOMContentLoaded', function () {
        if (window._wizGoTo) {
            @if ($errors->any())
                window._wizGoTo(5, true);
            @else
                window._wizGoTo(1, true);
            @endif
        }
    });
</script>
@stop