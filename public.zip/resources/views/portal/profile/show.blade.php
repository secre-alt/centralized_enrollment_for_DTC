@extends('adminlte::page')
@include('partials.navbar')

@section('title', 'Profile Settings')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h4 class="mb-0 font-weight-bold u-text">Profile Settings</h4>
            <p class="mb-0 u-text-secondary-sm">Manage your account information and password</p>
        </div>
    </div>
@endsection

@section('content')

@php
    $initials = collect(preg_split('/\s+/', trim($user->name)))
        ->filter()->take(2)
        ->map(fn($p) => strtoupper(substr($p, 0, 1)))->implode('');
@endphp

{{-- ── Flash alerts ─────────────────────────────────────────────────────── --}}
@if (session('success'))
<div class="alert dtc-alert-success d-flex align-items-center gap-2 mb-4" role="alert">
    <i data-lucide="check-circle" style="width:18px;height:18px;flex-shrink:0;"></i>
    <span>{{ session('success') }}</span>
</div>
@endif

@if ($errors->any() && !$errors->has('current_password') && !$errors->has('password'))
<div class="alert dtc-alert-danger d-flex align-items-center gap-2 mb-4" role="alert">
    <i data-lucide="alert-circle" style="width:18px;height:18px;flex-shrink:0;"></i>
    <span>Please fix the errors below before saving.</span>
</div>
@endif

<div class="row">
<div class="col-12" style="max-width:820px;">

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{-- HERO CARD                                                              --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="card mb-4 ps-hero-card">
    <div class="card-body d-flex align-items-center gap-3 flex-wrap">

        {{-- Avatar --}}
        <div class="ps-avatar-wrap">
            @if ($user->avatar)
                <img src="{{ Storage::url($user->avatar) }}"
                     alt="Profile photo"
                     class="ps-avatar-img">
            @else
                <div class="ps-avatar-initials">{{ $initials ?: 'U' }}</div>
            @endif
            <button type="button"
                    class="ps-avatar-edit-btn"
                    onclick="document.getElementById('avatarFileInput').click()"
                    title="Change photo"
                    aria-label="Change profile photo">
                <i data-lucide="pencil" style="width:12px;height:12px;"></i>
            </button>
        </div>

        {{-- Identity --}}
        <div>
            <div class="ps-hero-name">{{ $user->name }}</div>
            <div class="ps-hero-email">{{ $user->email }}</div>
            <span class="ps-role-badge">
                <i data-lucide="shield" style="width:11px;height:11px;"></i>
                @if ($user->hasRole('alumni'))
                    Alumni
                @elseif ($user->hasRole('student'))
                    Student
                @else
                    Portal User
                @endif
            </span>
        </div>
    </div>
</div>

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{-- PERSONAL INFORMATION                                                   --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="card mb-4">
    <div class="card-header ps-card-header">
        <div class="ps-card-icon ps-icon-blue">
            <i data-lucide="user" style="width:17px;height:17px;"></i>
        </div>
        <div>
            <div class="ps-card-title">Personal Information</div>
            <div class="ps-card-subtitle">Update your name, email and profile photo</div>
        </div>
    </div>
    <div class="card-body">
        <form method="POST"
              action="{{ route('portal.profile.update') }}"
              enctype="multipart/form-data"
              id="profileForm">
            @csrf
            @method('PUT')

            {{-- Hidden file input --}}
            <input type="file"
                   id="avatarFileInput"
                   name="avatar"
                   accept="image/jpeg,image/png,image/webp"
                   style="display:none">

            <div class="row">
                <div class="col-12 col-sm-6 mb-3">
                    <label for="name" class="ps-label">
                        Full Name <span class="text-danger">*</span>
                    </label>
                    <input type="text"
                           id="name"
                           name="name"
                           class="form-control ps-input @error('name') is-invalid @enderror"
                           value="{{ old('name', $user->name) }}"
                           placeholder="Enter your full name"
                           autocomplete="name"
                           required>
                    @error('name')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-12 col-sm-6 mb-3">
                    <label for="email" class="ps-label">
                        Email Address <span class="text-danger">*</span>
                    </label>
                    <input type="email"
                           id="email"
                           name="email"
                           class="form-control ps-input @error('email') is-invalid @enderror"
                           value="{{ old('email', $user->email) }}"
                           placeholder="you@example.com"
                           autocomplete="email"
                           required>
                    @error('email')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            {{-- Avatar preview strip --}}
            <div id="avatarPreviewRow" style="display:none;" class="align-items-center gap-3 mb-3">
                <img id="avatarPreview"
                     alt="Preview"
                     class="ps-avatar-preview">
                <div>
                    <div style="font-size:.82rem;font-weight:600;color:var(--dtc-text);">New photo selected</div>
                    <div style="font-size:.75rem;color:var(--dtc-text-secondary);">Save changes to apply.</div>
                </div>
                <button type="button"
                        id="clearAvatarBtn"
                        class="btn btn-sm btn-outline-secondary ml-auto">
                    <i data-lucide="x" style="width:13px;height:13px;"></i> Clear
                </button>
            </div>

            @error('avatar')
                <div class="text-danger small mb-3 d-flex align-items-center gap-1">
                    <i data-lucide="alert-circle" style="width:13px;height:13px;"></i>
                    {{ $message }}
                </div>
            @enderror

            <div class="d-flex align-items-center flex-wrap gap-2 mt-2">
                <button type="submit" class="btn btn-primary">
                    <i data-lucide="save" class="mr-1" style="width:15px;height:15px;"></i>
                    Save Changes
                </button>

                @if ($user->avatar)
                    <form method="POST"
                          action="{{ route('portal.profile.avatar.remove') }}"
                          data-confirm-title="Remove Profile Photo"
                          data-confirm-message="This will permanently remove your profile photo."
                          data-confirm-ok="Remove"
                          class="m-0">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-outline-danger btn-sm">
                            <i data-lucide="trash-2" class="mr-1" style="width:13px;height:13px;"></i>
                            Remove Photo
                        </button>
                    </form>
                @endif
            </div>
        </form>
    </div>
</div>

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{-- ACADEMIC RECORD (read-only, shown only when studentProfile exists)    --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
@if ($studentProfile)
<div class="card mb-4">
    <div class="card-header ps-card-header">
        <div class="ps-card-icon ps-icon-yellow">
            <i data-lucide="graduation-cap" style="width:17px;height:17px;"></i>
        </div>
        <div>
            <div class="ps-card-title">Academic Record</div>
            <div class="ps-card-subtitle">Managed by the Registrar — contact them for corrections</div>
        </div>
    </div>
    <div class="card-body p-0">

        <div class="ps-info-row">
            <div class="ps-info-icon"><i data-lucide="hash" style="width:14px;height:14px;"></i></div>
            <div>
                <div class="ps-info-label">Student Number</div>
                <div class="ps-info-value">{{ $studentProfile->student_number ?? '—' }}</div>
            </div>
        </div>

        @if ($studentProfile->program)
        <div class="ps-info-row">
            <div class="ps-info-icon"><i data-lucide="book-open" style="width:14px;height:14px;"></i></div>
            <div>
                <div class="ps-info-label">Program / Course</div>
                <div class="ps-info-value">{{ $studentProfile->program->name }}</div>
            </div>
        </div>
        @endif

        @if ($studentProfile->enrolled_ay)
        <div class="ps-info-row">
            <div class="ps-info-icon"><i data-lucide="calendar" style="width:14px;height:14px;"></i></div>
            <div>
                <div class="ps-info-label">Academic Year Enrolled</div>
                <div class="ps-info-value">{{ $studentProfile->enrolled_ay }}</div>
            </div>
        </div>
        @endif

        @if ($user->hasRole('alumni') && $studentProfile->graduation_year)
        <div class="ps-info-row">
            <div class="ps-info-icon"><i data-lucide="award" style="width:14px;height:14px;"></i></div>
            <div>
                <div class="ps-info-label">Graduation Year</div>
                <div class="ps-info-value">{{ $studentProfile->graduation_year }}</div>
            </div>
        </div>
        @endif

        @if ($studentProfile->admission_type)
        <div class="ps-info-row" style="border-bottom:none;">
            <div class="ps-info-icon"><i data-lucide="tag" style="width:14px;height:14px;"></i></div>
            <div>
                <div class="ps-info-label">Admission Type</div>
                <div class="ps-info-value">{{ ucfirst(str_replace('_', ' ', $studentProfile->admission_type)) }}</div>
            </div>
        </div>
        @endif

    </div>
</div>
@endif

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{-- CHANGE PASSWORD                                                        --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="card mb-4">
    <div class="card-header ps-card-header">
        <div class="ps-card-icon ps-icon-slate">
            <i data-lucide="lock" style="width:17px;height:17px;"></i>
        </div>
        <div>
            <div class="ps-card-title">Change Password</div>
            <div class="ps-card-subtitle">Choose a strong password — at least 8 characters</div>
        </div>
    </div>
    <div class="card-body">

        @if ($errors->has('current_password') || $errors->has('password'))
        <div class="alert dtc-alert-danger d-flex align-items-center gap-2 mb-3" role="alert">
            <i data-lucide="alert-circle" style="width:17px;height:17px;flex-shrink:0;"></i>
            <span>{{ $errors->first('current_password') ?: $errors->first('password') }}</span>
        </div>
        @endif

        <form method="POST"
              action="{{ route('portal.profile.password') }}"
              id="passwordForm">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label for="current_password" class="ps-label">
                    Current Password <span class="text-danger">*</span>
                </label>
                <div class="ps-pw-wrap">
                    <input type="password"
                           id="current_password"
                           name="current_password"
                           class="form-control ps-input ps-pw-input @error('current_password') is-invalid @enderror"
                           placeholder="Enter current password"
                           autocomplete="current-password"
                           required>
                    <button type="button"
                            class="ps-pw-toggle"
                            data-target="current_password"
                            aria-label="Toggle password visibility">
                        <i data-lucide="eye" style="width:16px;height:16px;"></i>
                    </button>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-sm-6 mb-3">
                    <label for="password" class="ps-label">
                        New Password <span class="text-danger">*</span>
                    </label>
                    <div class="ps-pw-wrap">
                        <input type="password"
                               id="password"
                               name="password"
                               class="form-control ps-input ps-pw-input @error('password') is-invalid @enderror"
                               placeholder="Min. 8 characters"
                               autocomplete="new-password"
                               required
                               minlength="8"
                               oninput="updateStrength(this.value)">
                        <button type="button"
                                class="ps-pw-toggle"
                                data-target="password"
                                aria-label="Toggle password visibility">
                            <i data-lucide="eye" style="width:16px;height:16px;"></i>
                        </button>
                    </div>
                    {{-- Strength bar --}}
                    <div class="ps-strength-bar mt-1">
                        <div class="ps-strength-fill" id="strengthFill"></div>
                    </div>
                    <div class="ps-strength-label" id="strengthLabel">Enter a new password</div>
                </div>

                <div class="col-12 col-sm-6 mb-3">
                    <label for="password_confirmation" class="ps-label">
                        Confirm New Password <span class="text-danger">*</span>
                    </label>
                    <div class="ps-pw-wrap">
                        <input type="password"
                               id="password_confirmation"
                               name="password_confirmation"
                               class="form-control ps-input ps-pw-input"
                               placeholder="Repeat new password"
                               autocomplete="new-password"
                               required
                               minlength="8">
                        <button type="button"
                                class="ps-pw-toggle"
                                data-target="password_confirmation"
                                aria-label="Toggle password visibility">
                            <i data-lucide="eye" style="width:16px;height:16px;"></i>
                        </button>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">
                <i data-lucide="lock" class="mr-1" style="width:15px;height:15px;"></i>
                Update Password
            </button>
        </form>
    </div>
</div>

</div>{{-- /col --}}
</div>{{-- /row --}}

{{-- ══════════════════════════════════════════════════════════════════════ --}}
{{-- AVATAR CROP MODAL                                                      --}}
{{-- ══════════════════════════════════════════════════════════════════════ --}}
<div class="modal fade" id="avatarCropModal" tabindex="-1" role="dialog" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width:520px;">
        <div class="modal-content ps-crop-modal">
            <div class="modal-header ps-crop-header">
                <div class="d-flex align-items-center gap-2">
                    <div class="ps-crop-header-icon">
                        <i data-lucide="image" style="width:16px;height:16px;"></i>
                    </div>
                    <h6 class="modal-title mb-0">Crop Profile Photo</h6>
                </div>
                <button type="button" class="close ps-crop-close" data-dismiss="modal" aria-label="Close">
                    <i data-lucide="x" style="width:18px;height:18px;"></i>
                </button>
            </div>
            <div class="modal-body ps-crop-body">
                <div class="ps-crop-hint">
                    <i data-lucide="move" style="width:13px;height:13px;"></i>
                    Drag to reposition &bull; Scroll to zoom &bull; Drag corner to resize
                </div>
                <div class="ps-crop-container">
                    <img id="cropImage" src="" alt="Crop preview" style="max-width:100%;display:block;">
                </div>
            </div>
            <div class="ps-crop-preview-bar">
                <span class="ps-crop-preview-label">Preview</span>
                <div class="ps-crop-previews">
                    <div class="text-center">
                        <div class="ps-preview-circle ps-preview-lg" id="previewLg"></div>
                        <div class="ps-preview-size">80 px</div>
                    </div>
                    <div class="text-center">
                        <div class="ps-preview-circle ps-preview-md" id="previewMd"></div>
                        <div class="ps-preview-size">48 px</div>
                    </div>
                    <div class="text-center">
                        <div class="ps-preview-circle ps-preview-sm" id="previewSm"></div>
                        <div class="ps-preview-size">32 px</div>
                    </div>
                </div>
            </div>
            <div class="modal-footer ps-crop-footer">
                <button type="button" class="btn ps-crop-btn-secondary" data-dismiss="modal">
                    <i data-lucide="x" style="width:14px;height:14px;"></i> Cancel
                </button>
                <button type="button" class="btn ps-crop-btn-rotate" id="cropRotateLeft" title="Rotate left">
                    <i data-lucide="rotate-ccw" style="width:14px;height:14px;"></i>
                </button>
                <button type="button" class="btn ps-crop-btn-rotate" id="cropRotateRight" title="Rotate right">
                    <i data-lucide="rotate-cw" style="width:14px;height:14px;"></i>
                </button>
                <button type="button" class="btn ps-crop-btn-primary" id="cropApplyBtn">
                    <i data-lucide="check" style="width:14px;height:14px;"></i> Apply &amp; Use Photo
                </button>
            </div>
        </div>
    </div>
</div>

@endsection

@section('css')
<style>
/* ── Profile Settings — scoped under .ps-* ─────────────────────────────── */

/* Hero card */
.ps-hero-card {
    background: linear-gradient(135deg, #1a56db 0%, #1e40af 100%);
    border: none;
    border-radius: 1rem;
    color: #fff;
}
.ps-hero-card .card-body { padding: 1.5rem 1.75rem; }

.ps-avatar-wrap { position: relative; flex-shrink: 0; }
.ps-avatar-img,
.ps-avatar-initials {
    width: 80px; height: 80px; border-radius: 50%;
    border: 3px solid rgba(255,255,255,.35);
    display: flex; align-items: center; justify-content: center;
}
.ps-avatar-img   { object-fit: cover; }
.ps-avatar-initials {
    background: rgba(255,255,255,.18);
    font-size: 1.75rem; font-weight: 700;
    color: #fff; letter-spacing: .5px;
    user-select: none;
}
.ps-avatar-edit-btn {
    position: absolute; bottom: 2px; right: 2px;
    width: 26px; height: 26px; border-radius: 50%;
    background: #fbbf24; border: 2px solid #fff;
    display: flex; align-items: center; justify-content: center;
    cursor: pointer; color: #1e3a8a; transition: background .2s;
}
.ps-avatar-edit-btn:hover { background: #f59e0b; }

.ps-hero-name  { font-size: 1.2rem; font-weight: 700; line-height: 1.3; }
.ps-hero-email { font-size: .85rem; opacity: .8; margin: .15rem 0 .4rem; }
.ps-role-badge {
    display: inline-flex; align-items: center; gap: .3rem;
    background: rgba(255,255,255,.18);
    border: 1px solid rgba(255,255,255,.25);
    border-radius: 999px; padding: .15rem .65rem;
    font-size: .75rem; font-weight: 600;
    text-transform: capitalize; letter-spacing: .3px;
}

/* Card header */
.ps-card-header {
    display: flex; align-items: center; gap: .75rem;
    padding: 1rem 1.25rem;
    background: var(--dtc-surface, #f8f9fc);
    border-bottom: 1px solid var(--dtc-border, #e5e9f0);
}
.ps-card-icon {
    width: 34px; height: 34px; border-radius: .5rem;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ps-icon-blue   { background: #dbeafe; color: #1d4ed8; }
.ps-icon-yellow { background: #fef9c3; color: #b45309; }
.ps-icon-slate  { background: #f1f5f9; color: #475569; }
.ps-card-title    { font-size: .9rem; font-weight: 700; color: var(--dtc-text, #1e293b); }
.ps-card-subtitle { font-size: .76rem; color: var(--dtc-text-secondary, #64748b); margin-top: .1rem; }

/* Form inputs */
.ps-label { font-size: .8rem; font-weight: 600; margin-bottom: .35rem; color: var(--dtc-text, #374151); }
.ps-input {
    border-radius: .5rem !important;
    border: 1.5px solid var(--dtc-border, #d1d9e6) !important;
    font-size: .875rem;
    transition: border-color .2s, box-shadow .2s;
}
.ps-input:focus {
    border-color: #3b82f6 !important;
    box-shadow: 0 0 0 3px rgba(59,130,246,.12) !important;
}

/* Password wrap + toggle */
.ps-pw-wrap { position: relative; }
.ps-pw-input { padding-right: 2.5rem !important; }
.ps-pw-toggle {
    position: absolute; right: .7rem; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer; padding: 0;
    color: #9ca3af; display: flex; align-items: center; line-height: 1;
}
.ps-pw-toggle:hover { color: var(--dtc-text, #374151); }

/* Strength bar */
.ps-strength-bar  { height: 4px; border-radius: 999px; background: #e5e9f0; overflow: hidden; }
.ps-strength-fill { height: 100%; border-radius: 999px; width: 0%; transition: width .3s, background .3s; }
.ps-strength-label { font-size: .73rem; font-weight: 600; margin-top: .25rem; color: #9ca3af; }

/* Read-only info rows */
.ps-info-row {
    display: flex; align-items: flex-start; gap: .75rem;
    padding: .85rem 1.25rem;
    border-bottom: 1px solid var(--dtc-border, #f0f3f8);
}
.ps-info-icon {
    width: 30px; height: 30px; border-radius: .45rem;
    background: var(--dtc-surface, #f1f5f9);
    color: var(--dtc-text-secondary, #475569);
    display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: .1rem;
}
.ps-info-label { font-size: .72rem; color: var(--dtc-text-secondary, #64748b); font-weight: 500; margin-bottom: .15rem; }
.ps-info-value { font-size: .88rem; color: var(--dtc-text, #1e293b); font-weight: 600; }

/* Avatar preview */
.ps-avatar-preview { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; border: 2px solid var(--dtc-border, #e5e9f0); }

/* Alerts */
.dtc-alert-success { background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d; border-radius: .6rem; }
.dtc-alert-danger  { background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; border-radius: .6rem; }

/* Gap utility for Bootstrap 4 */
.gap-2 { gap: .5rem; }
.gap-3 { gap: .75rem; }

/* ── Avatar Crop Modal ───────────────────────────────────────────────── */
.ps-avatar-preview { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; border: 2px solid var(--dtc-border, #e5e9f0); background: var(--dtc-surface, #f1f5f9); display: block; }

.ps-crop-modal { border: none; border-radius: 1rem; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,.18); }
.ps-crop-header { background: var(--dtc-surface, #f8f9fc); border-bottom: 1px solid var(--dtc-border, #e5e9f0); padding: .85rem 1.25rem; display: flex; align-items: center; justify-content: space-between; }
.ps-crop-header-icon { width: 30px; height: 30px; border-radius: .45rem; background: #dbeafe; color: #1d4ed8; display: flex; align-items: center; justify-content: center; }
.ps-crop-close { background: none; border: none; cursor: pointer; color: var(--dtc-text-secondary, #64748b); padding: .2rem; line-height: 1; transition: color .2s; }
.ps-crop-close:hover { color: var(--dtc-text, #1e293b); }
.ps-crop-body { padding: 1rem 1.25rem .75rem; }
.ps-crop-hint { display: flex; align-items: center; gap: .35rem; font-size: .72rem; color: var(--dtc-text-secondary, #64748b); background: #f0f9ff; border: 1px solid #bae6fd; border-radius: .45rem; padding: .35rem .65rem; margin-bottom: .85rem; }
.ps-crop-container { background: #0f172a; border-radius: .65rem; overflow: hidden; max-height: 320px; display: flex; align-items: center; justify-content: center; }
.cropper-view-box, .cropper-face { border-radius: 50%; }
.cropper-view-box { outline: 3px solid rgba(255,255,255,.9); }
.cropper-line { background-color: rgba(255,255,255,.6); }
.cropper-point { background-color: #fff; width: 8px; height: 8px; border-radius: 50%; opacity: .85; }
.cropper-point.point-n, .cropper-point.point-s { left: 50%; margin-left: -4px; }
.cropper-point.point-w, .cropper-point.point-e { top: 50%; margin-top: -4px; }
.ps-crop-preview-bar { padding: .75rem 1.25rem; background: var(--dtc-surface, #f8f9fc); border-top: 1px solid var(--dtc-border, #e5e9f0); display: flex; align-items: center; gap: 1.25rem; }
.ps-crop-preview-label { font-size: .72rem; font-weight: 700; color: var(--dtc-text-secondary, #64748b); text-transform: uppercase; letter-spacing: .5px; flex-shrink: 0; }
.ps-crop-previews { display: flex; align-items: flex-end; gap: 1rem; }
.ps-preview-circle { border-radius: 50%; overflow: hidden; border: 2px solid var(--dtc-border, #d1d9e6); }
.ps-preview-lg { width: 80px; height: 80px; }
.ps-preview-md { width: 48px; height: 48px; }
.ps-preview-sm { width: 32px; height: 32px; }
.ps-preview-size { font-size: .65rem; color: var(--dtc-text-secondary, #94a3b8); text-align: center; margin-top: .25rem; }
.ps-crop-footer { border-top: 1px solid var(--dtc-border, #e5e9f0); padding: .75rem 1.25rem; display: flex; align-items: center; gap: .5rem; flex-wrap: wrap; }
.ps-crop-btn-primary { background: #1a56db; color: #fff; border: none; border-radius: .5rem; padding: .45rem .9rem; font-size: .82rem; font-weight: 600; display: inline-flex; align-items: center; gap: .35rem; margin-left: auto; transition: background .2s; }
.ps-crop-btn-primary:hover { background: #1e40af; color: #fff; }
.ps-crop-btn-secondary { background: transparent; color: var(--dtc-text-secondary, #475569); border: 1.5px solid var(--dtc-border, #d1d9e6); border-radius: .5rem; padding: .4rem .85rem; font-size: .82rem; font-weight: 600; display: inline-flex; align-items: center; gap: .35rem; transition: border-color .2s, color .2s; }
.ps-crop-btn-secondary:hover { border-color: #94a3b8; color: var(--dtc-text, #1e293b); }
.ps-crop-btn-rotate { background: var(--dtc-surface, #f1f5f9); border: 1.5px solid var(--dtc-border, #d1d9e6); border-radius: .5rem; padding: .4rem .6rem; color: var(--dtc-text-secondary, #475569); display: inline-flex; align-items: center; transition: background .2s; }
.ps-crop-btn-rotate:hover { background: #e2e8f0; }
</style>
@endsection

@section('js')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.2/cropper.min.js"></script>
<script>
/* ── Avatar Crop ─────────────────────────────────────────────────────────── */
(function () {
    const avatarInput = document.getElementById('avatarFileInput');
    const cropImg     = document.getElementById('cropImage');
    const applyBtn    = document.getElementById('cropApplyBtn');
    const rotLBtn     = document.getElementById('cropRotateLeft');
    const rotRBtn     = document.getElementById('cropRotateRight');
    const previewRow  = document.getElementById('avatarPreviewRow');
    const previewImg  = document.getElementById('avatarPreview');
    const clearBtn    = document.getElementById('clearAvatarBtn');
    let cropper = null, originalName = 'avatar.jpg';

    if (avatarInput) {
        avatarInput.addEventListener('change', function () {
            const file = this.files[0];
            if (!file) return;
            originalName = file.name;
            const reader = new FileReader();
            reader.onload = function (e) {
                cropImg.src = e.target.result;
                if (cropper) { cropper.destroy(); cropper = null; }
                $('#avatarCropModal').modal('show');
            };
            reader.readAsDataURL(file);
            this.value = '';
        });
    }

    $('#avatarCropModal').on('shown.bs.modal', function () {
        cropper = new Cropper(cropImg, {
            aspectRatio: 1,
            viewMode: 1,
            dragMode: 'move',
            autoCropArea: 0.85,
            restore: false,
            guides: false,
            center: true,
            highlight: false,
            cropBoxMovable: true,
            cropBoxResizable: true,
            toggleDragModeOnDblclick: false,
            preview: [
                document.getElementById('previewLg'),
                document.getElementById('previewMd'),
                document.getElementById('previewSm'),
            ],
        });
        if (typeof lucide !== 'undefined') lucide.createIcons();
    });

    $('#avatarCropModal').on('hidden.bs.modal', function () {
        if (cropper) { cropper.destroy(); cropper = null; }
    });

    if (rotLBtn) rotLBtn.addEventListener('click', function () { if (cropper) cropper.rotate(-90); });
    if (rotRBtn) rotRBtn.addEventListener('click', function () { if (cropper) cropper.rotate(90); });

    if (applyBtn) {
        applyBtn.addEventListener('click', function () {
            if (!cropper) return;
            const canvas = cropper.getCroppedCanvas({ width: 400, height: 400, imageSmoothingEnabled: true, imageSmoothingQuality: 'high' });
            canvas.toBlob(function (blob) {
                const ext   = /\.png$/i.test(originalName) ? 'png' : 'jpeg';
                const mime  = ext === 'png' ? 'image/png' : 'image/jpeg';
                const fname = 'avatar.' + ext;
                try {
                    const dt = new DataTransfer();
                    dt.items.add(new File([blob], fname, { type: mime }));
                    avatarInput.files = dt.files;
                } catch (e) {
                    avatarInput._croppedBlob = blob;
                    avatarInput._croppedName = fname;
                }
                const blobUrl = URL.createObjectURL(blob);
                previewImg.onload = function () { URL.revokeObjectURL(blobUrl); };
                previewImg.src = blobUrl;
                previewRow.style.display = 'flex';
                $('#avatarCropModal').modal('hide');
            }, 'image/jpeg', 0.92);
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            avatarInput.value = '';
            avatarInput._croppedBlob = null;
            previewImg.removeAttribute('src');
            previewRow.style.display = 'none';
        });
    }

    /* Safari fallback */
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', function (e) {
            if (avatarInput._croppedBlob && avatarInput.files.length === 0) {
                e.preventDefault();
                const fd = new FormData(profileForm);
                fd.set('avatar', avatarInput._croppedBlob, avatarInput._croppedName);
                fetch(profileForm.action, {
                    method: 'POST',
                    body: fd,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                }).then(function (res) {
                    if (res.redirected) window.location.href = res.url;
                });
            }
        });
    }
})();

/* ── Password visibility toggle ──────────────────────────────────────────── */
document.querySelectorAll('.ps-pw-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
        const input = document.getElementById(this.dataset.target);
        if (!input) return;
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        const icon = this.querySelector('[data-lucide]');
        if (icon) {
            icon.setAttribute('data-lucide', show ? 'eye-off' : 'eye');
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }
    });
});

/* ── Password strength ───────────────────────────────────────────────────── */
function updateStrength(value) {
    const fill  = document.getElementById('strengthFill');
    const label = document.getElementById('strengthLabel');
    if (!fill || !label) return;
    let score = 0;
    if (value.length >= 8)          score++;
    if (/[A-Z]/.test(value))        score++;
    if (/[0-9]/.test(value))        score++;
    if (/[^A-Za-z0-9]/.test(value)) score++;
    const levels = [
        { pct: '0%',   color: '#e5e9f0', text: 'Enter a new password', textColor: '#9ca3af' },
        { pct: '25%',  color: '#ef4444', text: 'Weak',                  textColor: '#dc2626' },
        { pct: '50%',  color: '#f59e0b', text: 'Fair',                  textColor: '#b45309' },
        { pct: '75%',  color: '#3b82f6', text: 'Good',                  textColor: '#1d4ed8' },
        { pct: '100%', color: '#22c55e', text: 'Strong',                textColor: '#15803d' },
    ];
    const lvl = value.length === 0 ? levels[0] : (levels[score] || levels[1]);
    fill.style.width      = lvl.pct;
    fill.style.background = lvl.color;
    label.textContent     = lvl.text;
    label.style.color     = lvl.textColor;
}
</script>
@endsection