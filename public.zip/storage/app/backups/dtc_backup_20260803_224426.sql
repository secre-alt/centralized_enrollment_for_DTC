-- DTC EMS Database Backup
-- Generated: 2026-08-03 22:44:26
-- Database: dtc_enrollment

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `appointment_slots`;
CREATE TABLE `appointment_slots` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `max_bookings` int(11) NOT NULL DEFAULT 5,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `appointment_slots` VALUES
('1', '2026-07-03', '08:21:00', '20:21:00', '5', '2026-07-03 10:19:30', '2026-07-03 10:19:30'),
('2', '2026-07-05', '07:40:00', '19:40:00', '1', '2026-07-03 23:41:09', '2026-07-03 23:41:09'),
('3', '2026-07-07', '07:51:00', '17:00:00', '1', '2026-07-03 23:51:46', '2026-07-03 23:51:46'),
('4', '2026-07-08', '07:47:00', '19:47:00', '5', '2026-07-04 23:47:28', '2026-07-04 23:47:28'),
('5', '2026-07-24', '03:56:00', '15:56:00', '5', '2026-07-19 07:56:39', '2026-07-19 07:56:39');

DROP TABLE IF EXISTS `appointments`;
CREATE TABLE `appointments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `appointment_slot_id` bigint(20) unsigned NOT NULL,
  `document_type` varchar(255) NOT NULL,
  `purpose` text DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointments_user_id_foreign` (`user_id`),
  KEY `appointments_appointment_slot_id_foreign` (`appointment_slot_id`),
  CONSTRAINT `appointments_appointment_slot_id_foreign` FOREIGN KEY (`appointment_slot_id`) REFERENCES `appointment_slots` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `appointments` VALUES
('1', '3', '1', 'diploma', 'employment', 'confirmed', NULL, '2026-07-03 10:24:16', '2026-07-03 10:25:01'),
('2', '3', '2', 'tor', 'scholarship', 'confirmed', NULL, '2026-07-03 23:41:49', '2026-07-03 23:53:41'),
('3', '3', '3', 'diploma', 'employment', 'confirmed', NULL, '2026-07-03 23:52:35', '2026-07-03 23:53:37'),
('4', '3', '4', 'transcript', 'ddfd', 'pending', NULL, '2026-07-04 23:48:03', '2026-07-04 23:48:03'),
('5', '5', '4', 'tor', 'employment', 'cancelled', NULL, '2026-07-06 12:20:39', '2026-07-19 07:57:36'),
('6', '5', '5', 'transcript', 'Employment', 'pending', NULL, '2026-07-19 07:57:26', '2026-07-19 07:57:26');

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_created_at_index` (`created_at`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `status` varchar(255) NOT NULL DEFAULT 'completed',
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_logs_created_by_foreign` (`created_by`),
  CONSTRAINT `backup_logs_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `certificates`;
CREATE TABLE `certificates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `course_subjects`;
CREATE TABLE `course_subjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `program_id` bigint(20) unsigned NOT NULL,
  `subject_code` varchar(255) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `year_level` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_subjects_program_id_foreign` (`program_id`),
  CONSTRAINT `course_subjects_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_subjects` VALUES
('1', '1', 'IS101', 'Introduction to Computing', '1', '1', '2026-06-19 11:44:19', '2026-06-19 11:44:19'),
('2', '1', 'IS102', 'Computer Programming 1', '1', '1', '2026-06-19 11:44:19', '2026-06-19 11:44:19'),
('3', '1', 'IS103', 'Discrete Mathematics', '1', '1', '2026-06-19 11:44:19', '2026-06-19 11:44:19'),
('4', '1', 'GE101', 'Purposive Communication', '1', '1', '2026-06-19 11:44:19', '2026-06-19 11:44:19');

DROP TABLE IF EXISTS `document_requests`;
CREATE TABLE `document_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `appointment_id` bigint(20) unsigned DEFAULT NULL,
  `document_type` varchar(255) NOT NULL,
  `copies` int(11) NOT NULL DEFAULT 1,
  `purpose` text DEFAULT NULL,
  `status` enum('submitted','processing','ready','released') NOT NULL DEFAULT 'submitted',
  `fee` decimal(8,2) NOT NULL DEFAULT 0.00,
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  `receipt_no` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `document_requests_user_id_foreign` (`user_id`),
  KEY `document_requests_appointment_id_foreign` (`appointment_id`),
  CONSTRAINT `document_requests_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `document_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `document_requests` VALUES
('1', '5', '5', 'tor', '2', 'employment', 'released', '100.00', '0', NULL, NULL, '2026-07-06 12:20:39', '2026-07-06 12:22:57');

DROP TABLE IF EXISTS `enrollments`;
CREATE TABLE `enrollments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `program_id` bigint(20) unsigned NOT NULL,
  `year_level` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `subject_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`subject_ids`)),
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `remarks` text DEFAULT NULL,
  `is_paid` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enrollments_user_id_foreign` (`user_id`),
  KEY `enrollments_program_id_foreign` (`program_id`),
  CONSTRAINT `enrollments_program_id_foreign` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`),
  CONSTRAINT `enrollments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `enrollments` VALUES
('1', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'approved', NULL, '1', '2026-06-19 11:45:55', '2026-06-19 11:48:21'),
('2', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'approved', NULL, '1', '2026-06-20 00:54:31', '2026-06-20 00:55:37'),
('3', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'pending', NULL, '0', '2026-07-03 23:52:51', '2026-07-03 23:52:51'),
('4', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'rejected', 'gsd', '0', '2026-07-04 15:13:57', '2026-07-04 15:15:37'),
('5', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'pending', NULL, '0', '2026-07-04 15:24:38', '2026-07-04 15:24:38'),
('6', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'pending', NULL, '0', '2026-07-04 15:26:05', '2026-07-04 15:26:05'),
('7', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'rejected', 'ds', '0', '2026-07-04 23:41:24', '2026-07-04 23:42:32'),
('8', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'approved', NULL, '1', '2026-07-04 23:45:47', '2026-07-06 00:33:51'),
('9', '3', '1', '1', '1', '[\"1\",\"2\",\"3\",\"4\"]', 'approved', NULL, '1', '2026-07-06 00:25:34', '2026-07-06 00:29:32');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES
('1', '2014_10_12_000000_create_users_table', '1'),
('2', '2014_10_12_100000_create_password_resets_table', '1'),
('3', '2019_08_19_000000_create_failed_jobs_table', '1'),
('4', '2019_12_14_000001_create_personal_access_tokens_table', '1'),
('5', '2026_06_18_043815_create_permission_tables', '1'),
('6', '2026_06_18_043820_create_programs_table', '1'),
('7', '2026_06_18_043829_create_appointments_table', '1'),
('8', '2026_06_18_043830_create_enrollments_table', '1'),
('9', '2026_06_18_043838_create_payments_table', '1'),
('10', '2026_06_18_043848_create_certificates_table', '1'),
('11', '2026_06_18_044711_add_status_to_users_table', '1'),
('12', '2026_06_19_013553_create_course_subjects_table', '1'),
('13', '2026_06_20_002948_create_notifications_table', '2'),
('14', '2026_06_20_003009_create_user_notifications_table', '2'),
('15', '2026_06_30_220654_create_appointment_slots_table', '3'),
('16', '2026_06_30_221949_create_appointments_table', '4'),
('17', '2026_07_06_120153_create_document_requests_table', '5'),
('19', '2026_07_30_134348_create_audit_logs_table', '6'),
('20', '2026_07_30_134301_create_settings_table', '7'),
('21', '2026_08_02_133156_create_backup_logs_table', '8');

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_roles` VALUES
('1', 'App\\Models\\User', '1'),
('2', 'App\\Models\\User', '4'),
('3', 'App\\Models\\User', '2'),
('4', 'App\\Models\\User', '11'),
('5', 'App\\Models\\User', '3'),
('5', 'App\\Models\\User', '10'),
('6', 'App\\Models\\User', '5');

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `enrollment_id` bigint(20) unsigned NOT NULL,
  `processed_by` bigint(20) unsigned NOT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT 500.00,
  `receipt_no` varchar(255) NOT NULL,
  `paid_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_receipt_no_unique` (`receipt_no`),
  KEY `payments_enrollment_id_foreign` (`enrollment_id`),
  KEY `payments_processed_by_foreign` (`processed_by`),
  CONSTRAINT `payments_enrollment_id_foreign` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_processed_by_foreign` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `payments` VALUES
('1', '1', '2', '500.00', 'OR-20260619-YW3SY', '2026-06-19 11:48:21', '2026-06-19 11:48:21', '2026-06-19 11:48:21'),
('2', '2', '2', '500.00', 'OR-20260620-LG2PH', '2026-06-20 00:55:37', '2026-06-20 00:55:37', '2026-06-20 00:55:37'),
('3', '9', '2', '500.00', 'OR-20260706-TUHYT', '2026-07-06 00:29:32', '2026-07-06 00:29:32', '2026-07-06 00:29:32'),
('4', '8', '2', '500.00', 'OR-20260706-CGXRV', '2026-07-06 00:33:51', '2026-07-06 00:33:51', '2026-07-06 00:33:51');

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `programs`;
CREATE TABLE `programs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `programs` VALUES
('1', 'BS Information Systems', 'BSIS', '2026-06-19 11:44:19', '2026-06-19 11:44:19');

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` VALUES
('1', 'admin', 'web', '2026-06-19 11:44:03', '2026-06-19 11:44:03'),
('2', 'registrar', 'web', '2026-06-19 11:44:03', '2026-06-19 11:44:03'),
('3', 'cashier', 'web', '2026-06-19 11:44:03', '2026-06-19 11:44:03'),
('4', 'new_applicant', 'web', '2026-06-19 11:44:03', '2026-06-19 11:44:03'),
('5', 'student', 'web', '2026-06-19 11:44:03', '2026-06-19 11:44:03'),
('6', 'alumni', 'web', '2026-06-19 11:44:03', '2026-06-19 11:44:03');

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` VALUES
('1', 'institution_name', 'Danao Technological College', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('2', 'system_name', 'DTC Enrollment Management System (EMS)', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('3', 'tagline', 'Excellence in Education, Service to the Community.', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('4', 'address', 'Sta. Rosa St., Danao City, Cebu, Philippines', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('5', 'default_language', 'en', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('6', 'default_timezone', 'Asia/Manila', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('7', 'date_format', 'm/d/Y', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('8', 'time_format', '12', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('9', 'items_per_page', '10', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('10', 'maintenance_mode', '0', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('11', 'enrollment_fee', '500', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('12', 'gcash_number', '', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('13', 'gcash_name', '', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('14', 'enrollment_open', '1', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('15', 'email_notifications', '1', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('16', 'sms_notifications', '0', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('17', 'app_notifications', '1', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('18', 'min_password_length', '8', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('19', 'require_special_chars', '0', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('20', 'session_timeout', '60', '2026-07-31 05:00:10', '2026-07-31 05:00:10'),
('21', 'max_login_attempts', '5', '2026-07-31 05:00:10', '2026-07-31 05:00:10');

DROP TABLE IF EXISTS `user_notifications`;
CREATE TABLE `user_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_notifications_user_id_foreign` (`user_id`),
  CONSTRAINT `user_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_notifications` VALUES
('1', '3', 'Enrollment Approved', 'Your enrollment has been approved. Please proceed to the Cashier to pay the ₱500.00 enrollment fee.', 'success', 'http://127.0.0.1:8000/portal/enrollment/2/payment-info', '2026-06-20 00:56:14', '2026-06-20 00:55:09', '2026-06-20 00:56:14'),
('2', '3', 'Payment Confirmed — Enrollment Complete', 'Your payment of ₱500.00 has been recorded. Receipt No: OR-20260620-LG2PH. You are now officially enrolled!', 'success', 'http://127.0.0.1:8000/cashier/payments/2/receipt', '2026-06-20 00:56:25', '2026-06-20 00:55:37', '2026-06-20 00:56:25'),
('3', '3', 'Appointment Confirmed', 'Your appointment for Diploma has been confirmed on Jul 03, 2026 at 08:21 AM.', 'success', 'http://127.0.0.1:8000/portal/appointments', '2026-07-03 17:27:49', '2026-07-03 10:25:01', '2026-07-03 17:27:49'),
('4', '4', 'New Appointment Request', 'Trianne Sano has booked an appointment for Diploma on Jul 07, 2026 at 07:51 AM.', 'info', 'http://127.0.0.1:8000/registrar/appointments', '2026-07-04 15:28:32', '2026-07-03 23:52:36', '2026-07-04 15:28:32'),
('5', '1', 'New Appointment Request', 'Trianne Sano has booked an appointment for Diploma on Jul 07, 2026.', 'info', 'http://127.0.0.1:8000/registrar/appointments', '2026-07-04 15:13:09', '2026-07-03 23:52:36', '2026-07-04 15:13:09'),
('6', '4', 'New Enrollment Submission', 'Trianne Sano has submitted an enrollment request for BS Information Systems — Year 1, Semester 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-04 15:28:32', '2026-07-03 23:52:51', '2026-07-04 15:28:32'),
('7', '3', 'Appointment Confirmed', 'Your appointment for Diploma has been confirmed on Jul 07, 2026 at 07:51 AM.', 'success', 'http://127.0.0.1:8000/portal/appointments', '2026-07-03 23:55:07', '2026-07-03 23:53:37', '2026-07-03 23:55:07'),
('8', '3', 'Appointment Confirmed', 'Your appointment for Tor has been confirmed on Jul 05, 2026 at 07:40 AM.', 'success', 'http://127.0.0.1:8000/portal/appointments', '2026-07-03 23:55:02', '2026-07-03 23:53:41', '2026-07-03 23:55:02'),
('9', '4', 'New Enrollment Submission', 'Trianne Sano has submitted an enrollment request for BS Information Systems — Year 1, Semester 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-04 15:28:32', '2026-07-04 15:13:57', '2026-07-04 15:28:32'),
('10', '3', 'Enrollment Rejected', 'Your enrollment was rejected. Reason: gsd', 'danger', 'http://127.0.0.1:8000/portal/enrollment', '2026-07-04 15:24:23', '2026-07-04 15:15:37', '2026-07-04 15:24:23'),
('11', '4', 'New Enrollment Submission', 'Trianne Sano has submitted an enrollment request for BS Information Systems — Year 1, Semester 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-04 15:28:32', '2026-07-04 15:24:39', '2026-07-04 15:28:32'),
('12', '4', 'New Enrollment Submission', 'Trianne Sano submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-04 15:28:32', '2026-07-04 15:26:05', '2026-07-04 15:28:32'),
('13', '4', 'New Enrollment Submission', 'Trianne Sano submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-06 00:27:27', '2026-07-04 23:41:24', '2026-07-06 00:27:27'),
('14', '1', 'New Enrollment Submission', 'Trianne Sano submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-04 23:42:03', '2026-07-04 23:41:24', '2026-07-04 23:42:03'),
('15', '3', 'Enrollment Rejected', 'Your enrollment was rejected. Reason: ds', 'danger', 'http://127.0.0.1:8000/portal/enrollment', '2026-07-04 23:45:29', '2026-07-04 23:42:32', '2026-07-04 23:45:29'),
('16', '4', 'New Enrollment Submission', 'Trianne Sano submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-06 00:27:27', '2026-07-04 23:45:47', '2026-07-06 00:27:27'),
('17', '1', 'New Enrollment Submission', 'Trianne Sano submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-04 23:51:39', '2026-07-04 23:45:47', '2026-07-04 23:51:39'),
('18', '4', 'New Appointment Request', 'Trianne Sano has booked an appointment for Transcript on Jul 08, 2026 at 07:47 AM.', 'info', 'http://127.0.0.1:8000/registrar/appointments', '2026-07-06 00:27:27', '2026-07-04 23:48:03', '2026-07-06 00:27:27'),
('19', '1', 'New Appointment Request', 'Trianne Sano has booked an appointment for Transcript on Jul 08, 2026.', 'info', 'http://127.0.0.1:8000/registrar/appointments', '2026-07-04 23:51:39', '2026-07-04 23:48:03', '2026-07-04 23:51:39'),
('20', '3', 'Enrollment Approved', 'Your enrollment has been approved. Please proceed to the Cashier to pay the ₱500.00 enrollment fee.', 'success', 'http://127.0.0.1:8000/portal/enrollment/8/payment-info', '2026-07-06 00:24:30', '2026-07-04 23:51:17', '2026-07-06 00:24:30'),
('21', '4', 'New Enrollment Submission', 'Trianne Sano submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-06 00:27:31', '2026-07-06 00:25:34', '2026-07-06 00:27:31'),
('22', '1', 'New Enrollment Submission', 'Trianne Sano submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-06 00:26:46', '2026-07-06 00:25:34', '2026-07-06 00:26:46'),
('23', '3', 'Enrollment Approved', 'Your enrollment has been approved by the Registrar. Please proceed to the Cashier to pay the ₱500.00 enrollment fee.', 'success', 'http://127.0.0.1:8000/portal/enrollment/9/payment-info', '2026-07-14 13:39:47', '2026-07-06 00:28:28', '2026-07-14 13:39:47'),
('24', '2', 'Enrollment Ready for Payment', 'Trianne Sano\'s enrollment has been approved. They are ready to pay the ₱500.00 enrollment fee.', 'info', 'http://127.0.0.1:8000/cashier/payments', '2026-07-06 00:33:43', '2026-07-06 00:28:28', '2026-07-06 00:33:43'),
('25', '1', 'Enrollment Approved', 'Registrar approved Trianne Sano\'s enrollment for BS Information Systems.', 'success', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-06 00:31:41', '2026-07-06 00:28:28', '2026-07-06 00:31:41'),
('26', '3', 'Payment Confirmed — Enrollment Complete', 'Your payment of ₱500.00 has been recorded. Receipt No: OR-20260706-TUHYT. You are now officially enrolled!', 'success', 'http://127.0.0.1:8000/portal/enrollment', '2026-07-14 13:39:47', '2026-07-06 00:29:32', '2026-07-14 13:39:47'),
('27', '4', 'Payment Received', 'Trianne Sano has paid the enrollment fee of ₱500.00. Receipt No: OR-20260706-TUHYT.', 'success', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-06 12:21:05', '2026-07-06 00:29:32', '2026-07-06 12:21:05'),
('28', '1', 'Payment Received', 'Trianne Sano has paid the enrollment fee of ₱500.00. Receipt No: OR-20260706-TUHYT.', 'success', 'http://127.0.0.1:8000/cashier/payments', '2026-07-06 00:31:41', '2026-07-06 00:29:32', '2026-07-06 00:31:41'),
('29', '3', 'Payment Confirmed — Enrollment Complete', 'Your payment of ₱500.00 has been recorded. Receipt No: OR-20260706-CGXRV. You are now officially enrolled!', 'success', 'http://127.0.0.1:8000/portal/enrollment', '2026-07-14 13:39:47', '2026-07-06 00:33:51', '2026-07-14 13:39:47'),
('30', '4', 'Payment Received', 'Trianne Sano has paid the enrollment fee of ₱500.00. Receipt No: OR-20260706-CGXRV.', 'success', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-06 12:21:05', '2026-07-06 00:33:51', '2026-07-06 12:21:05'),
('31', '1', 'Payment Received', 'Trianne Sano has paid the enrollment fee of ₱500.00. Receipt No: OR-20260706-CGXRV.', 'success', 'http://127.0.0.1:8000/cashier/payments', '2026-07-06 12:17:56', '2026-07-06 00:33:51', '2026-07-06 12:17:56'),
('32', '4', 'New Document Request', 'alumni (Alumni) requested Transcript of Records — 2 copies.', 'info', 'http://127.0.0.1:8000/registrar/documents', '2026-07-06 12:22:49', '2026-07-06 12:20:39', '2026-07-06 12:22:49'),
('33', '1', 'New Document Request', 'alumni (Alumni) submitted a document request.', 'info', 'http://127.0.0.1:8000/registrar/documents', '2026-07-06 22:42:28', '2026-07-06 12:20:39', '2026-07-06 22:42:28'),
('34', '5', 'Document Request Update', 'Your document is ready for pickup! Please proceed to the Registrar\'s Office.', 'success', 'http://127.0.0.1:8000/portal/documents', '2026-07-06 12:22:20', '2026-07-06 12:21:54', '2026-07-06 12:22:20'),
('35', '5', 'Document Request Update', 'Your document has been released. Thank you!', 'info', 'http://127.0.0.1:8000/portal/documents', '2026-07-06 12:23:21', '2026-07-06 12:22:57', '2026-07-06 12:23:21'),
('36', '4', 'New Enrollment Submission', 'Enrollee submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-14 14:04:44', '2026-07-06 22:45:04', '2026-07-14 14:04:44'),
('37', '1', 'New Enrollment Submission', 'Enrollee submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-14 13:57:10', '2026-07-06 22:45:04', '2026-07-14 13:57:10'),
('38', '4', 'New Enrollment Submission', 'Enrollee submitted an enrollment for BS Information Systems — Year 1, Sem 1.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-14 14:04:47', '2026-07-14 14:03:08', '2026-07-14 14:04:47'),
('39', '1', 'New Enrollment Submission', 'Enrollee submitted an enrollment for BS Information Systems.', 'info', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-16 12:43:01', '2026-07-14 14:03:08', '2026-07-16 12:43:01'),
('41', '2', 'Enrollment Ready for Payment', 'Enrollee\'s enrollment has been approved. They are ready to pay the ₱500.00 enrollment fee.', 'info', 'http://127.0.0.1:8000/cashier/payments', '2026-07-14 14:05:55', '2026-07-14 14:04:55', '2026-07-14 14:05:55'),
('42', '1', 'Enrollment Approved', 'Registrar approved Enrollee\'s enrollment for BS Information Systems.', 'success', 'http://127.0.0.1:8000/registrar/enrollments', '2026-07-16 12:43:01', '2026-07-14 14:04:55', '2026-07-16 12:43:01'),
('44', '1', 'Payment Received', 'Enrollee has paid the ₱500.00 enrollment fee. Receipt No: OR-20260714-B35AY.', 'success', 'http://127.0.0.1:8000/cashier/payments', '2026-07-16 12:43:01', '2026-07-14 14:06:09', '2026-07-16 12:43:01'),
('45', '4', 'Enrollment Payment Received', 'Enrollee has completed payment and is now officially enrolled.', 'success', 'http://127.0.0.1:8000/registrar/enrollments', NULL, '2026-07-14 14:06:09', '2026-07-14 14:06:09'),
('46', '4', 'New Appointment Request', 'alumni has booked an appointment for Transcript on Jul 24, 2026 at 03:56 AM.', 'info', 'http://127.0.0.1:8000/registrar/appointments', NULL, '2026-07-19 07:57:26', '2026-07-19 07:57:26'),
('47', '1', 'New Appointment Request', 'alumni has booked an appointment for Transcript on Jul 24, 2026.', 'info', 'http://127.0.0.1:8000/registrar/appointments', '2026-08-02 13:25:00', '2026-07-19 07:57:26', '2026-08-02 13:25:00'),
('48', '4', 'Appointment Cancelled', 'alumni has cancelled their appointment booking for Tor.', 'warning', 'http://127.0.0.1:8000/registrar/appointments', NULL, '2026-07-19 07:57:36', '2026-07-19 07:57:36'),
('49', '1', 'Appointment Cancelled', 'alumni has cancelled their appointment booking for Tor.', 'warning', 'http://127.0.0.1:8000/registrar/appointments', '2026-08-02 13:25:00', '2026-07-19 07:57:36', '2026-08-02 13:25:00');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` enum('active','pending','locked') NOT NULL DEFAULT 'active',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES
('1', 'Administrator', 'admin@dtc.edu.ph', 'active', NULL, '$2y$10$EydKZdXt8tm.Lb6FQOJ/6uXjpZJtBp5O4hm8iBj7gkf6b4hpDEfkm', 'cfBL4KZ41LfPtYzQnTEf3f9XvY48yZsauDOPGgiXTvPTdyG5014GpC6k7jXB', '2026-06-19 11:44:03', '2026-06-19 11:44:03'),
('2', 'Cashier', 'cashier@dtc.edu.ph', 'active', NULL, '$2y$10$Ek65Bio6aZUjoGdftGpq.OqAbJyHKz3kT6de180fdNjrSy/aoC6aq', '4aCEuj4H7Ad6hMPvjb7UlTO0fFqXR5O6xTWfZfVLz8YUXaCpsdHUAZstRm4x', '2026-06-19 11:45:14', '2026-06-19 11:45:14'),
('3', 'Trianne Sano', 'triannesano@gmail.com', 'active', NULL, '$2y$10$qhQ0QfxzM.Y337dVtRFHuOZiK0HlbWzn1mrEcPdutZcAfn7fJ/LiS', '2gLFFplmFn4SkSCiK6MnM9OvVd4Js2r8eOSk7JL7RKNvkzgMnqiQNuS64Rgu', '2026-06-19 11:45:26', '2026-06-19 11:45:26'),
('4', 'registrar', 'registrar@dtc.edu.ph', 'active', NULL, '$2y$10$Qmunb0G4fFZSuvAptjJzc.luFb8CocoZkkS6HTfoN8AOKQJJCSrTm', 'kl72uogwTHxE0CmCvecAs0waDKolBQ17ViR05oLUdfjMvmgQmlbxJn16tQO7', '2026-06-19 11:47:20', '2026-06-19 11:47:20'),
('5', 'alumni', 'alumni@dtc.edu.ph', 'active', NULL, '$2y$10$HwwXcx5/i6T7Pf5Sm3piC.KdQ90OypGre3RWbXeurKHbwC5BftN7O', NULL, '2026-07-06 12:18:58', '2026-07-06 12:18:58'),
('10', 'student', 'student@dtc.edu.ph', 'active', NULL, '$2y$10$mgHzTOD5lMP4FqbFb83m/.DOP6neGgMODFEl8NM4UNmNnA6I2/vFC', NULL, '2026-07-16 12:52:37', '2026-07-16 12:52:37'),
('11', 'Ren Cruz', 'Enrollee@dtc.edu.ph', 'active', NULL, '$2y$10$yRKlJcD1vTco6szspuFgB.OrsQ1u0oQ4qEeTb5bnZQbdpoeQu1xw6', 'P49ZTMj2SImmbb5Rcty5k7RYaMBAuRxsa6SO8NYNNiuvOi764Y6KGW7M5YlV', '2026-07-22 02:46:53', '2026-07-22 02:46:53');

SET FOREIGN_KEY_CHECKS=1;
