@extends('adminlte::page')
@include('partials.navbar')

@section('title', 'Pending Enrollments')

@section('content_header')
    <div>
        <h4 class="mb-0 font-weight-bold" style="color:var(--dtc-text);">Pending Enrollments</h4>
        <p class="mb-0" style="color:var(--dtc-text-secondary); font-size:13px;">
            Enrollment submissions awaiting registrar approval.
        </p>
    </div>
@endsection

@section('content')

@if (session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

@if (session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif

{{-- Enrollments Table --}}
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="font-weight-bold" style="color:var(--dtc-text);">All Pending Enrollments</span>
        <span style="font-size:13px; color:var(--dtc-text-secondary);">{{ $enrollments->total() }} total</span>
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
        <table class="table table-bordered mb-0">
            <thead>
                <tr>
                    <th>Applicant</th>
                    <th>Program</th>
                    <th>Year / Semester</th>
                    <th>Submitted</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                @forelse ($enrollments as $enrollment)
                <tr>
                    <td>{{ $enrollment->user->name }}</td>
                    <td>{{ $enrollment->program->name }}</td>
                    <td>Year {{ $enrollment->year_level }} - Sem {{ $enrollment->semester }}</td>
                    <td>{{ $enrollment->created_at->format('M d, Y h:i A') }}</td>
                    <td>
                        <a href="{{ route('registrar.enrollments.show', $enrollment) }}" class="btn btn-sm btn-primary">
                            Review
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5" class="text-center py-4" style="color:var(--dtc-text-muted);">
                        No pending enrollments.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
        </div>
    </div>

    @if($enrollments->hasPages())
    <div class="card-footer" style="background:var(--dtc-surface); border-top:1px solid var(--dtc-border);">
        <div class="d-flex justify-content-between align-items-center flex-wrap" style="gap:15px;">
            <small style="color:var(--dtc-text-secondary);">
                Showing
                <strong>{{ $enrollments->firstItem() }}</strong>
                to
                <strong>{{ $enrollments->lastItem() }}</strong>
                of
                <strong>{{ $enrollments->total() }}</strong>
                enrollments
            </small>

            <div>
                {{ $enrollments->onEachSide(1)->links('pagination::bootstrap-4') }}
            </div>
        </div>
    </div>
    @endif
</div>

@endsection