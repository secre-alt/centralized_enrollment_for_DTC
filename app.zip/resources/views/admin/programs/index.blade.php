@extends('adminlte::page')
@include('partials.navbar')

@section('title', 'Programs & Subjects')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center flex-wrap" style="gap:10px;">
        <div>
            <h4 class="mb-0 font-weight-bold" style="color:var(--dtc-text);">Programs & Subjects</h4>
            <p class="mb-0" style="color:var(--dtc-text-secondary); font-size:13px;">
                Manage academic programs and their subjects
            </p>
        </div>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addProgramModal">
            <i class="fas fa-plus mr-1"></i> Add Program
        </button>
    </div>
@endsection

@section('content')

@if (session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

{{-- ============ PROGRAMS ============ --}}
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span class="font-weight-bold" style="color:var(--dtc-text);">All Programs</span>
        <span style="font-size:13px; color:var(--dtc-text-secondary);">{{ $programs->total() }} total</span>
    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Program</th>
                        <th>Code</th>
                        <th>Subjects</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($programs as $program)
                    <tr>
                        <td>
                            <div style="font-size:13px; font-weight:600; color:var(--dtc-text);">
                                {{ $program->name }}
                            </div>
                        </td>
                        <td>
                            <span style="background:#EEF2FF; color:#0F4CDB; font-size:12px;
                                         font-weight:700; padding:3px 10px; border-radius:20px;
                                         white-space:nowrap; display:inline-block;">
                                {{ $program->code }}
                            </span>
                        </td>
                        <td>
                            <span style="font-size:13px; font-weight:600; color:var(--dtc-text);">
                                {{ $program->subjects_count }}
                            </span>
                            <span style="font-size:12px; color:var(--dtc-text-muted);"> subjects</span>
                        </td>
                        <td>
                            <div style="display:flex; gap:6px;">
                                <a href="{{ route('admin.programs.index', ['program' => $program->id]) }}"
                                   style="background:{{ $selectedProgram && $selectedProgram->id === $program->id ? '#0F4CDB' : '#EEF2FF' }};
                                          color:{{ $selectedProgram && $selectedProgram->id === $program->id ? '#fff' : '#0F4CDB' }};
                                          border:none; padding:5px 12px; border-radius:8px; font-size:11px;
                                          font-weight:600; text-decoration:none; white-space:nowrap;">
                                    <i class="fas fa-book mr-1"></i> Subjects
                                </a>
                                <form method="POST"
                                      action="{{ route('admin.programs.destroy', $program) }}">
                                    @csrf @method('DELETE')
                                    <button type="submit"
                                            style="background:#FEE2E2; color:#DC2626; border:none;
                                                   padding:5px 12px; border-radius:8px;
                                                   font-size:11px; font-weight:600; cursor:pointer;"
                                            onclick="return confirm('Delete {{ $program->name }}?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="text-center py-4" style="color:var(--dtc-text-muted);">
                            No programs yet.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-footer d-flex justify-content-between align-items-center flex-wrap" style="gap:15px;">
        <small style="color:var(--dtc-text-secondary);">
            Showing
            <strong>{{ $programs->firstItem() ?? 0 }}</strong>
            to
            <strong>{{ $programs->lastItem() ?? 0 }}</strong>
            of
            <strong>{{ $programs->total() }}</strong>
            programs
        </small>

        @if($programs->hasPages())
        <div>
            {{ $programs->appends(request()->except('page'))->onEachSide(1)->links('pagination::bootstrap-4') }}
        </div>
        @endif
    </div>
</div>

{{-- ============ SUBJECTS ============ --}}
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap" style="gap:10px;">
        <div>
            <span class="font-weight-bold" style="color:var(--dtc-text);">
                Subjects
                @if($selectedProgram)
                    — {{ $selectedProgram->name }} ({{ $selectedProgram->code }})
                @endif
            </span>
            @if(!$selectedProgram)
                <div style="font-size:12px; color:var(--dtc-text-muted); margin-top:2px;">
                    Select a program above to manage its subjects.
                </div>
            @endif
        </div>
        @if($selectedProgram)
        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addSubjectModal">
            <i class="fas fa-plus mr-1"></i> Add Subject
        </button>
        @endif
    </div>

    @if($selectedProgram)
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Subject Name</th>
                        <th>Year</th>
                        <th>Semester</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($subjects as $subject)
                    <tr>
                        <td>
                            <span style="background:#EEF2FF; color:#0F4CDB; font-size:12px;
                                         font-weight:700; padding:3px 10px; border-radius:20px;
                                         white-space:nowrap; display:inline-block;">
                                {{ $subject->subject_code }}
                            </span>
                        </td>
                        <td style="font-size:13px; color:var(--dtc-text);">
                            {{ $subject->subject_name }}
                        </td>
                        <td style="font-size:12px; color:var(--dtc-text-secondary);">
                            {{ $subject->year_level }}{{ ['','st','nd','rd','th'][$subject->year_level] ?? 'th' }} Year
                        </td>
                        <td style="font-size:12px; color:var(--dtc-text-secondary);">
                            {{ $subject->semester }}{{ $subject->semester == 1 ? 'st' : 'nd' }} Sem
                        </td>
                        <td>
                            <form method="POST"
                                  action="{{ route('admin.programs.subjects.destroy', $subject) }}">
                                @csrf @method('DELETE')
                                <button type="submit"
                                        style="background:#FEE2E2; color:#DC2626;
                                               border:none; padding:4px 10px;
                                               border-radius:8px; font-size:11px;
                                               font-weight:600; cursor:pointer;"
                                        onclick="return confirm('Remove this subject?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center py-4" style="color:var(--dtc-text-muted);">
                            No subjects added yet for this program.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="card-footer d-flex justify-content-between align-items-center flex-wrap" style="gap:15px;">
        <small style="color:var(--dtc-text-secondary);">
            Showing
            <strong>{{ $subjects->firstItem() ?? 0 }}</strong>
            to
            <strong>{{ $subjects->lastItem() ?? 0 }}</strong>
            of
            <strong>{{ $subjects->total() }}</strong>
            subjects
        </small>

        @if($subjects->hasPages())
        <div>
            {{ $subjects->appends(request()->except('subjects_page'))->onEachSide(1)->links('pagination::bootstrap-4') }}
        </div>
        @endif
    </div>
    @endif
</div>

{{-- ============ ADD PROGRAM MODAL ============ --}}
<div class="modal fade" id="addProgramModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form method="POST" action="{{ route('admin.programs.store') }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus-circle mr-2" style="color:#0F4CDB;"></i> Add New Program
                    </h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Program Name</label>
                        <input type="text" name="name" class="form-control"
                               placeholder="e.g. BS Information Systems"
                               value="{{ old('name') }}" required>
                    </div>
                    <div class="form-group">
                        <label>Program Code</label>
                        <input type="text" name="code" class="form-control"
                               placeholder="e.g. BSIS"
                               value="{{ old('code') }}" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus mr-1"></i> Add Program
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- ============ ADD SUBJECT MODAL ============ --}}
@if($selectedProgram)
<div class="modal fade" id="addSubjectModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form method="POST"
                  action="{{ route('admin.programs.subjects.store', $selectedProgram) }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus-circle mr-2" style="color:#0F4CDB;"></i>
                        Add Subject — {{ $selectedProgram->code }}
                    </h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Subject Code</label>
                        <input type="text" name="subject_code" class="form-control"
                               placeholder="e.g. IS101" required>
                    </div>
                    <div class="form-group">
                        <label>Subject Name</label>
                        <input type="text" name="subject_name" class="form-control"
                               placeholder="e.g. Introduction to Computing" required>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Year Level</label>
                                <select name="year_level" class="form-control" required>
                                    <option value="1">1st Year</option>
                                    <option value="2">2nd Year</option>
                                    <option value="3">3rd Year</option>
                                    <option value="4">4th Year</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Semester</label>
                                <select name="semester" class="form-control" required>
                                    <option value="1">1st Sem</option>
                                    <option value="2">2nd Sem</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus mr-1"></i> Add Subject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif

@if($errors->any())
<script>
    $(function(){
        @if($errors->has('subject_code') || $errors->has('subject_name') || $errors->has('year_level') || $errors->has('semester'))
            $('#addSubjectModal').modal('show');
        @elseif($errors->has('name') || $errors->has('code'))
            $('#addProgramModal').modal('show');
        @endif
    });
</script>
@endif

@endsection